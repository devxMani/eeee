int secondLargest(vector<int> &a, int n)
{
    int largest = a[0];
    int slargest = -1;
    for (int i = 1; i < n; i++)
    {

        if (a[i] > largest)
        {
            slargest = largest;
            largest = a[i];
        }

        else if (a[i] < largest && a[i] > slargest)
        {
            slargest = a[i];
        }
    }
    return slargest;
}

/*
secondLargest Function:

Explanation:

Initial Setup:

largest is initialized to the first element a[0].
slargest (second largest) is initialized to -1.

Iteration:

Loop through the array starting from the second element (i = 1 to n-1).

Update Conditions:

If the current element a[i] is greater than largest, then update slargest to be the old largest and update largest to be a[i].
If the current element a[i] is less than largest but greater than slargest, update slargest to a[i].

Return:

Return slargest which will hold the second largest value in the array.
*/

int secondSmallest(vector<int> &a, int n)
{
    int smallest = a[0];
    int ssmallest = INT_MAX;
    for (int i = 1; i < n; i++)
    {
        if (a[i] < smallest)
        {
            ssmallest = smallest;
            smallest = a[i];
        }
        else if (a[i] != smallest && a[i] < ssmallest)
        {
            ssmallest = a[i];
        }
    }
    return ssmallest;
}

/*

Explanation:
Initial Setup:

largest is initialized to the first element a[0].
slargest (second largest) is initialized to -1.
Iteration:

Loop through the array starting from the second element (i = 1 to n-1).
Update Conditions:

If the current element a[i] is greater than largest, then update slargest to be the old largest and update largest to be a[i].
If the current element a[i] is less than largest but greater than slargest, update slargest to a[i].
Return:

Return slargest which will hold the second largest value in the array.

*/

vector<int> getSecondOrderElements(int n, vector<int> a) int slargest = secondLargest(a, n); // a means array
int ssmallest = secondSmallest(a, n);

return {slargest, ssmallest};
}


/*
getSecondOrderElements Function:
Explanation:
Function Call:
Call secondLargest to get the second largest element and store it in slargest.
Call secondSmallest to get the second smallest element and store it in ssmallest.
Return:
Return a vector containing slargest and ssmallest.
Summary:
The secondLargest function identifies the second largest element by keeping track of the largest and second largest values encountered during a single pass through the array.
The secondSmallest function identifies the second smallest element by keeping track of the smallest and second smallest values encountered during a single pass through the array.
The getSecondOrderElements function combines the results of these two functions and returns them in a vector.
This solution is efficient with a time complexity of
𝑂
(
𝑛
)
O(n) since it only requires a single pass through the array for both the largest and smallest element calculations.

*/