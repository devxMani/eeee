#include <iostream>
#include <vector>
#include <algorithm> // for std::reverse

void reverseArray(std::vector<int>& arr) {
    std::reverse(arr.begin(), arr.end());
}

int main() {
    std::vector<int> arr = {1, 2, 3, 4, 5};

    std::cout << "Original array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;

    reverseArray(arr);

    std::cout << "Reversed array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;

    return 0;
}
