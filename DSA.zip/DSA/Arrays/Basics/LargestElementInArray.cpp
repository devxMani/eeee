class Solution
{
public:
    int largest(vector<int> &arr, int n)
    /* It takes two parameters:
vector<int> &arr: A reference to a vector of integers, representing the array.
int n: An integer representing the size of the array.*/
    {
        int largest = arr[0];
        for (int i = 0; i < n; i++)
        {
            if (arr[i] > largest)
            {
                largest = arr[i];
            }
        }
        return largest;
    }
};
