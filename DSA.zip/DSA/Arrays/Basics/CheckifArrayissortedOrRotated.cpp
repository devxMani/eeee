class Solution
{
public:
    /*
    The function check takes a reference to a vector of integers nums as an input and returns a boolean value.
   n is initialized to the size of the array.
   count is initialized to 0 to keep track of the number of times the order of elements decreases.
   */
    bool check(vector<int> &nums)
    {
        int n = nums.size();
        int count = 0;

        /*
        A for loop starts from the second element (i = 1) and iterates through each element of the array.
For each element at index i, it compares nums[i - 1] with nums[i].
If nums[i - 1] is greater than nums[i], it indicates a point of rotation or an unsorted point, so count is incremented.
        */

        for (int i = 1; i < n; i++)
            if (nums[i - 1] > nums[i])
                count++;

        /*
        After the loop completes, there's an additional check for the wrap-around condition: if the last element nums[n - 1] is greater than the first element nums[0], it indicates another point of rotation.
If this condition is true, count is incremented.
*/

        if (nums[n - 1] > nums[0])
            count++;
        /*
        Finally, the function returns true if count is less than or equal to 1.
If count is 0 or 1, it means the array is either already sorted without rotation, or it is sorted with at most one point of rotation. In either case, it satisfies the problem's condition.
        */

        return count <= 1;
    }
};