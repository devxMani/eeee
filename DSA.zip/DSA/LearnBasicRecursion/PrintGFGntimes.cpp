#include <bits/stdc++.h>
using namespace std;

class Solution {
  public:
    void printGfg(int N) {
        // Code here
        if(N==0){
            return;
        }
        cout<<"GFG ";
        return printGfg(N-1);
    }
};