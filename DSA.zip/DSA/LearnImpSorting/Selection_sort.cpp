#include <bits/stdc++.h>
using namespace std;

void selection_sort(int arr[], int n)
{ // This function takes an array arr and its size n as arguments and sorts the array using the Selection Sort algorithm.
    // selection sort

    /* 1-The outer loop iterates over each element of the array except the last one.
    2-mini is used to store the index of the smallest element in the unsorted part of the array.
        3-The inner loop starts from i + 1 and checks for the smallest element in the unsorted part of the array.
        4-If a smaller element is found (arr[j] < arr[mini]), mini is updated to j.
        5-After the inner loop, the smallest element is swapped with the element at index i.*/
//////////////////////////////// MAINCODE ALGO
    for (int i = 0; i < n - 1; i++)
    {
        int mini = i;
        for (int j = i + 1; j < n; j++)
        {
            if (arr[j] < arr[mini])
            {
                mini = j;
            }
        }
        int temp = arr[mini];
        arr[mini] = arr[i];
        arr[i] = temp;
    }

    // This code prints the sorted array after the Selection Sort algorithm is applied.

    cout << "After selection sort: " << "\n";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
//////////////////////////////// MAINCODE ALGO


/* 1-An array arr is initialized with some integers.
2-The size of the array n is calculated using sizeof(arr) / sizeof(arr[0]).
3-The array is printed before sorting.
4-The selection_sort function is called to sort the array.
5-The sorted array is printed after sorting.*/

int main()
{
    int arr[] = {13, 46, 24, 52, 20, 9};
    int n = sizeof(arr) / sizeof(arr[0]);
    cout << "Before selection sort: " << "\n";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
    selection_sort(arr, n);
    return 0;
}
