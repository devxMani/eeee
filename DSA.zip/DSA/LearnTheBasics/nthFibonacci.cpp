#include <iostream>
using namespace std;

class Solution
{
public:
    long long nthFibonnaci(int n)
    { // Function Signature:

        if (n == 0)
            return 0; // Base Cases:
        if (n == 1)
            return 1;

        long long a = 0, b = 1; // Iterative Calculation:
        for (int i = 2; i <= n; ++i)
        {
            long long next = a + b;
            a = b;
            b = next;
        }
// Returning the Result:
        return b;
    }
};

int main()
{
    Solution sol;
    int n;
    cout << "Enter the value of n:";
    cin >> n;
    cout << "The " << n << "th Fibonnaci number is :" << sol.nthFibonnaci(n) << endl;
    return 0;
}