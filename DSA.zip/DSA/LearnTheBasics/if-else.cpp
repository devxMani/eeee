//User function Template for C++

class Solution {
  public:
    string compareNM(int n, int m){
        if(n<m){
            return "lesser";
        }
        else if(m==n){
            return "equal";
        }
        else{
            return "greater";
        }
    }
};


