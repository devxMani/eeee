#include <iostream>
#include <cmath>

class Solution {
public:
    bool isArmstrong(int N) {
        int originalNumber = N;
        int sum = 0;
        int numberOfDigits = 0;
        
        // Calculate the number of digits in N
        int temp = N;
        while (temp > 0) {
            temp /= 10;
            numberOfDigits++;
        }

        // Calculate the sum of each digit raised to the power of numberOfDigits
        temp = N;
        while (temp > 0) {
            int digit = temp % 10;
            sum += pow(digit, numberOfDigits);
            temp /= 10;
        }

        // Check if the sum is equal to the original number
        return sum == originalNumber;
    }
};

int main() {
    Solution sol;
    int N = 153; // Example input
    if (sol.isArmstrong(N)) {
        std::cout << N << " is an Armstrong number." << std::endl;
    } else {
        std::cout << N << " is not an Armstrong number." << std::endl;
    }
    return 0;
}
