class Solution {
public:
    int evenlyDivides(int N) {
        int count = 0; // Initialize a counter to store the count of digits that evenly divide N
        int n = N; // Make a copy of N to work with

        while (n != 0) { // Loop until all digits are processed
            int digit = n % 10; // Get the last digit of n
            if (digit != 0 && N % digit == 0) { // Check if the digit is non-zero and divides N evenly
                count += 1; // Increment the counter if the digit divides N evenly
            }
            n = n / 10; // Remove the last digit from n
        }

        return count; // Return the count of digits that evenly divide N
    }
};

