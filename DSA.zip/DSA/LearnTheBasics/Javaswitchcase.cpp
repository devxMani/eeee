#include <iostream>
#include <vector>
#include <cmath> // For pi value we have to import cmath

using namespace std;

class Solution
{
public:
    double switchCase(int choice, vector<double> &arr)
    {

        switch (choice)
        {
        case 1:
            return arr[0] * arr[0] * M_1_PI; // here circle area is calculated

        case 2:
            return arr[0] * arr[1];

        default:
            return -1.0; // unexpected choice
        }
    }
};

int main()
{
    Solution sol;
    vector<double> arr1 = {3.0};      // example for circle arr1 = radius
    vector<double> arr2 = {3.0, 4.0}; // example for rectangle arr2= lenght,width

    cout << "Area of circle" << sol.switchCase(1, arr1) << endl;    // print the area of circle
    cout << "Area of rectangle" << sol.switchCase(2, arr2) << endl; // print the area of rectangle

    return 0;
}
