#include <iostream>

class Solution {
public:
    long long sumOfDivisors(int N) {
        long long sum = 0;
        // Loop through each number from 1 to N
        for (int i = 1; i <= N; ++i) {
            // Add i * (N / i) to the sum
            sum += i * (N / i);
        }
        return sum;
    }
};

int main() {
    Solution sol;
    int N = 6; // Example input
    std::cout << "Sum of all divisors from 1 to " << N << " is: " << sol.sumOfDivisors(N) << std::endl;
    return 0;
}
