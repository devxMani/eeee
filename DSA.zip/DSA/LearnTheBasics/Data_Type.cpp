class Solution
{
public:
    int dataTypeSize(string str)
    {
        //         // The function takes a string 'str' and returns the size of the corresponding data type.

        if (str == "Character")
            //  // If the input string is "Character", return the size of 'char'.
            return sizeof(char);

        else if (str == "Integer")
            return sizeof(int);

        else if (str == "Long")
            return sizeof(long);

        else if (str == "Float")
            return sizeof(float);

        else if (str == "Double")
            return sizeof(double);

        return 0;
    }
};
