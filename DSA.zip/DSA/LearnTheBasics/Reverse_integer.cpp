class Solution {
public:
    int reverse(int x) {
        int ans = 0; // Initialize the variable 'ans' to store the reversed number.
        while(x != 0) { // Continue the loop until 'x' becomes 0.
            int digit = x % 10; // Extract the last digit of 'x'.
            
            // Check if reversing the number would cause an overflow.
            if((ans > INT_MAX/10) || (ans < INT_MIN/10)) {
                return 0; // Return 0 if it would overflow.
            }
            
            ans = (ans * 10) + digit; // Add the digit to 'ans' at the right place.
            x = x / 10; // Remove the last digit from 'x'.
        }
        return ans; // Return the reversed number.
    }
};
