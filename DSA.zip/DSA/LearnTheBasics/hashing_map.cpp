/* The header file <bits/stdc++.h> includes all standard C++ libraries.
using namespace std; allows us to avoid prefixing standard library names with std::.*/

#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n; // This reads an integer n which represents the size of the array.
    cin >> n;

    // This creates an array arr of size n and reads n integers into the array from the standard input.
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    // pre compute

    /* Here, mpp is a map (associative array) that stores the frequency of each
    integer in the array. The loop iterates over each element of arr,
    using the integer as the key in the map and incrementing its value to count occurrences.*/

    map<int, int> mpp;
    for (int i = 0; i < n; i++)
    {
        mpp[arr[i]]++;
    }
    // map

    /*This loop iterates over the map mpp and prints each key-value pair,
    where it.first is the integer and it.second is its frequency*/

    for (auto it : mpp)
    {
        cout << it.first << "->" << it.second << endl;
    }

    /*The program then reads an integer q, which is the number of queries.
    For each query, it reads an integer number, looks up its frequency in the
    map mpp, and prints the frequency. If number does not exist in the map, the map returns 0 by default.*/

    int q;
    cin >> q;
    while (q--)
    {
        int number;
        cin >> number;
        // fetch
        cout << mpp[number] << endl;
    }
    return 0;
}

/*
Explanation:

The input array has 5 elements: 1, 2, 2, 3, 3.
The mpp map after pre-computation will look like this: {1: 1, 2: 2, 3: 2}.
There are 3 queries:
For the first query 1, mpp[1] = 1.
For the second query 2, mpp[2] = 2.
For the third query 3, mpp[3] = 2.

Output:


1->1
2->2
3->2
1
2
2
*/