#include <iostream>
#include <vector>

class Solution {
public:
    // Function to find the GCD using the Euclidean algorithm
    long long findGCD(long long A, long long B) {
        if (B == 0) return A;
        return findGCD(B, A % B);
    }

    // Function to find the LCM and GCD of two numbers
    std::vector<long long> lcmAndGcd(long long A, long long B) {
        // Find GCD
        long long gcd = findGCD(A, B);
        // Find LCM using the relationship between GCD and LCM
        long long lcm = (A * B) / gcd;
        // Store the results in a vector
        std::vector<long long> result;
        result.push_back(lcm);
        result.push_back(gcd);
        return result;
    }
};

int main() {
    Solution sol;
    long long A = 15;
    long long B = 20;
    std::vector<long long> result = sol.lcmAndGcd(A, B);

    std::cout << "LCM: " << result[0] << ", GCD: " << result[1] << std::endl;
    return 0;
}



