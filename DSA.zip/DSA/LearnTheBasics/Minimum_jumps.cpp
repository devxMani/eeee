#include <iostream>
#include <vector>
#include <climits>
using namespace std;

class Solution {
public:
    int minJumps(vector<int>& arr) {
        int n = arr.size();
        if (n <= 1) return 0; // If array has one or no elements, no jumps are needed
        if (arr[0] == 0) return -1; // If the first element is 0, we cannot move anywhere

        int maxReach = arr[0]; // The farthest index that can be reached
        int step = arr[0]; // Steps we can still take
        int jumps = 1; // Number of jumps needed

        for (int i = 1; i < n; ++i) {
            if (i == n - 1) return jumps; // If we've reached the end of the array

            maxReach = max(maxReach, i + arr[i]); // Update the maxReach
            step--; // Use a step to move to the next index

            if (step == 0) { // If no more steps are left
                jumps++; // We need another jump
                if (i >= maxReach) return -1; // If the current position is beyond or equal to maxReach, we can't move further
                step = maxReach - i; // Reinitialize the steps to the amount of steps to reach maxReach from i
            }
        }

        return -1; // If we exit the loop without returning, we can't reach the end
    }
};

int main() {
    Solution sol;
    vector<int> arr = {1, 3, 5, 8, 9, 2, 6, 7, 6, 8, 9};
    int result = sol.minJumps(arr);
    cout << "Minimum number of jumps to reach the end is: " << result << endl;
    return 0;
}
