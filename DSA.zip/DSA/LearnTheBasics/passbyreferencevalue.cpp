#include <iostream>
#include <vector>
using namespace std;

class Solution
{
public:
    vector<int> passedBy(int a, int &b)
    { /* a: an integer passed by value.
b: an integer passed by reference (denoted by &).*/
        vector<int> result(2); /*Inside the function, a vector<int> named result is initialized with a size of 2. This vector will hold two integer values.*/
        result[0] = a + 1;
        result[1] = b + 2;
        return result;
    }
};

int main()
{
    Solution sol;
    int a = 5;
    int b = 10;
    vector<int> result = sol.passedBy(a, b);

    cout << "Result[0]: " << result[0] << endl; // Should print 6
    cout << "Result[1]: " << result[1] << endl; // Should print 12

    return 0;
}
