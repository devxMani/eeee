#include <iostream>
using namespace std;

class Geeks {
public:
    static void printTable(int n) {
        int multiplier = 10;
        while (multiplier > 0) {
            cout << multiplier * n << " ";
            multiplier--;
        }
        cout << endl;
    }
};

int main() {
    int n;
    cout << "Enter a number: ";
    cin >> n;
    Geeks::printTable(n);
    return 0;
}
// example output 50 45 40 35 30 25 20 15 10 5 
